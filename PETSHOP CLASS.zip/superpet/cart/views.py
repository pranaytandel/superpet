from django.shortcuts import render,HttpResponseRedirect
from .models import Cart,CartItem
from products.models import Product

# Create your views here.
def add_to_cart (request,productId):
    CurentUser=request.user
    cart,created=Cart.objects.get_or_create(user=CurentUser)
    quantity=request.GET.get("quantity")

    product=Product.manager.get(id=productId)

    cartitem,created=CartItem.objects.get_or_create(cart=cart,product=product)
    cartitem.quantity+=int(quantity)
    cartitem.save()
    

    #print(cart,creted)
    return HttpResponseRedirect("/products")





def cart(request):
    cart,created=Cart.objects.get_or_create(user=request.user)
    cartitems=cart.cartitem_set.all()
    total=0
    for cartitem in cartitems:
        total+=cartitem.quantity*cartitem.product.product_price

    return render(request,"cart.html",{"cartitems":cartitems,"total":total}) 


def remove_from_card(request,cartItemId):
    cartitem=CartItem.objects.get(id=cartItemId)
    cartitem.delete()
    return HttpResponseRedirect("/cart")

def update_cart(request,cartItemId):
    quantity=request.GET.get("quantity")
    cartitem=CartItem.objects.get(id=cartItemId)
    cartitem.quantity=quantity
    cartitem.save()
    return HttpResponseRedirect("/cart")