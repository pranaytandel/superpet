from django.urls import path
from .views import ProductListView
from.views import ProductDetailView
from.views import royalCaninProducts,CategoryDetailView,search

urlpatterns =[
    path("",ProductListView.as_view(),name="products"),
    path("<int:pk>",ProductDetailView.as_view(),name="productdetail"),
    path("royal-Canin-Products/",royalCaninProducts,name="royalcanin"),
    path("<slug:slug>",CategoryDetailView.as_view(),name="category"),
    path("search/",search,name="search"),

]