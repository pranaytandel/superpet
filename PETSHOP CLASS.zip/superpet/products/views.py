from django.shortcuts import render
from django.views.generic import ListView,DetailView
from products.models import Product,Category

# Create your views here.

class ProductListView(ListView):
    model=Product

class ProductDetailView(DetailView):
    model=Product
    template_name="products/product_detail.html"
    context_object_name="product"

def royalCaninProducts(requst):
    royalCaninProducts=Product.cm.royalCanin
    return render(requst,"products/product_brand.html",{"products":royalCaninProducts})

#==============================================================
#category detail view

class CategoryDetailView(DetailView):
    model=Category
    template_name="category/category.html"
    context_object_name="category"
    slug_field="category_slug"

#===================================
#search

def search(request):
    keyword=request.GET.get("keyword")
    products=Product.manager.all().filter( product_name__icontains=keyword)
    return render(request,"products/search.html",{"products":products})
    

